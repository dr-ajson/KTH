# Kategorier och placering

Källa: redaktionens process- och promptbeskrivning ("Ny process för löpande omvärldsbevakning", sökprompt version 2606). Kategorierna används både i veckorapporterna, i betygsfilen (en flik per kategori) och i den färdiga utgåvan, i denna ordning:

1. **Universitet och högskolor** – lärosäten, högre utbildning, akademisk frihet, styrning, finansiering, kvalitet, antagning, studentfrågor, forskarkarriärer och universitetssektorns villkor.
2. **AI** – AI:s påverkan på högre utbildning, forskning, forskningsetik, publicering, undervisning, examination, arbetsmarknad, reglering och kunskapsproduktion, men även strategiska AI-trender utan direkt koppling till sektorn.
3. **STEM** – skola, lärarutbildning, kompetensförsörjning, teknik- och naturvetenskapsutbildning i grund- och gymnasieskola. Särskilt svenska källor. Inte forskningsresultat eller högskolenyheter inom STEM-ämnen.
4. **Samverkan och innovation** – samverkan akademi–samhälle–näringsliv, forskningsinfrastruktur, kommersialisering, innovationspolitik, industrisamarbeten och strategiska satsningar. Särskilt svenska källor.
5. **Hållbar utveckling** – klimat, miljö, energi, social hållbarhet och Agenda 2030 när kopplingen till forskning, utbildning, innovation eller lärosäten är tydlig. Särskilt svenska källor.
6. **Europa och EU** – EU:s forsknings- och utbildningspolitik, Horisont Europa, Erasmus+, europeisk konkurrenskraft, reglering, forskningssamarbeten och europeiska lärosätesfrågor.
7. **Globalt** – utveckling utanför Sverige och EU/EES med tydlig relevans för sektorn: USA, Storbritannien, Kina, internationella organisationer, geopolitik, forskningssäkerhet, mobilitet och globala universitetstrender.
8. **Analyser och policydokument** – nya rapporter, policybriefs, offentliga utredningar, statistikrapporter, strategidokument, remisser, lagförslag och större analyser, när dokumentets analys- eller policyvärde är viktigare än ämnet.
9. **Debatt** – argumenterande eller opinionsdrivna texter (debattinlägg, ledare, krönikor) med koppling till högre utbildning och forskning, främst från dagstidningar, nischtidningar och fackliga tidningar; lärosätens egna texter bara om de är tydligt argumenterande.

Därefter, när det finns: **Pågående utredningar/remisser** – tabell med remisser som KTH hanterar (Dnr, Inkom datum, Rubrik, Från, Svar senast, Lottas till/Avstå).

## När ett inlägg passar i flera kategorier

- AI-reglering på EU-nivå: AI om AI-konsekvensen är huvudfrågan, annars Europa och EU.
- En rapport som i sig är nyheten: Analyser och policydokument.
- Svenska STEM-frågor: STEM, även om de berör universitet.
- Lärosätesspecifika nyheter: Universitet och högskolor, om de inte tydligt domineras av AI, EU, innovation eller hållbarhet.

Varje inlägg förekommer i exakt en kategori.

## Urval till utgåvan

Redaktionen (fyra personer) betygsätter varje inlägg 0–2 i Excelfilen. Summa 6 eller mer ger "Med", 4–5 "Kanske", 3 eller mindre "Nej". Vid redaktionsmötet omvärderas alla "Kanske" till "Med" eller "Nej". Utgåvan byggs av raderna där kolumnen **Med?** är "Med".
