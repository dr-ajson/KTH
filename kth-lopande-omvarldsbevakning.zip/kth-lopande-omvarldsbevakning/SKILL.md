---
name: kth-lopande-omvarldsbevakning
description: Bygger utgåvor av Ledningens omvärldsbevakning (KTH:s löpande omvärldsbevakning för ledningen) i den egna Word-mallen, från redaktionens betygsatta Excelfil eller från ett markdownutkast, med kategorier, inlägg (rubrik, sammanfattning, länk) och tabellen över pågående utredningar och remisser. Använd när användaren vill skapa, sammanställa eller uppdatera ledningens omvärldsbevakning, en månadsutgåva, ett utkast av omvärldsbevakningen eller göra om veckorapporter/Excelfilen till det färdiga dokumentet.
---

# Ledningens omvärldsbevakning

Ledningens omvärldsbevakning ger KTH:s ledning ett urval av aktuella händelser, rapporter och debatt i KTH:s omvärld. Den kommer ut några gånger per termin och har ett fast format: titel med datum, en inledning om syftet, inlägg ordnade i nio kategorier och till sist en tabell med pågående utredningar och remisser. Mallen `assets/KTH_lopandeomvarld.dotx` bär KTH:s logotyp, sidfot med sidnummer och formatmallarna som utgåvorna använder.

## Arbetsflödet som skillen ingår i

1. Veckovisa sökningar ger veckorapporter och debattrapporter (de senaste 14 dagarna, i kategorierna nedan).
2. Rapporterna slås ihop till en Excelfil med en flik per kategori och kolumnerna Publikationsdatum, Titel, Sammanfattning, Länk, en betygskolumn per redaktionsmedlem (0–2), Summa och **Med?**.
3. Redaktionen betygsätter och avgör vid redaktionsmötet vilka inlägg som är "Med".
4. **Den här skillen** bygger utgåvan av de inlägg som är "Med".

Kategorier, placeringsregler och urvalskriterier finns i `references/kategorier.md`.

## Bygg en utgåva

```bash
python scripts/bygg_omvarldsbevakning.py \
    --excel Omvarldsbevakning_2026-09-07_2026-09-26.xlsx \
    --datum 2026-10-06 \
    --utgivning "9 september, 6 oktober, 10 november och 15 december HT2026" \
    --remisser remisser.xlsx \
    -o "Ledningens omvärldsbevakning oktober 2026.docx"
```

- `--excel`: redaktionens fil. Rader med "Med" i kolumnen Med? tas med. Saknas värdet används Summa ≥ 6 (`--min-summa`). `--alla` tar med allt, för ett internt utkast.
- `--md`: alternativ indata i formatet `# Kategori` / `## Titel` / sammanfattning / länk (samma format som veckorapporterna och prompten "Skapa utkast till omvärldsbevakning"). Rader som `Länk:` och `Publiceringsdatum:` tolkas.
- `--datum`: utgivningsdatum, hamnar i titeln "Ledningens omvärldsbevakning ÅÅÅÅ-MM-DD".
- `--utgivning`: terminens utgivningsdatum. Ersätter inledningens sista mening; mallens egen mening är inaktuell. Fråga användaren om datumen saknas.
- `--remisser`: Excelfil med remisser (samma kolumner som mallen "Mall Remisser löpande omvärldsbevakning"). Utelämnas den blir det ingen remissektion.

Skriptet ordnar kategorierna i fast ordning, tar bort dubbletter (samma länk i flera flikar), gör länkarna klickbara och sätter titel, ämne och språk i dokumentegenskaperna. Kräver `python-docx` och `openpyxl`.

Filnamn enligt tidigare utgåvor: `Ledningens omvärldsbevakning <månad> <år>.docx`.

## Innehåll och kvalitet

Varje inlägg består av rubrik, en sammanfattning på svenska och länken. Sammanfattningen ska vara saklig, 40–60 ord, beskriva vad källan säger och varför det är relevant för ett tekniskt universitet, utan egna värderingar. Rubriken får vara på originalspråket om den är en egen titel (rapport, artikel), annars en svensk sammanfattande rubrik.

Innan utgåvan levereras:
1. Kör skillen `qa-link` på innehållet om den finns: alla länkar ska fungera och sammanfattningarna får inte påstå mer än källan. Rätta i Excelfilen eller markdownutkastet och bygg om, så att källfilen och dokumentet stämmer överens.
2. Kontrollera att varje inlägg ligger i rätt kategori enligt `references/kategorier.md` och att inget förekommer två gånger.
3. Använd KTH:s terminologi (skillen `kth-ordlista`) när engelska begrepp återges på svenska eller tvärtom.
4. Rendera och titta på resultatet (`soffice --headless --convert-to pdf`), särskilt remisstabellen.

## Redovisa för användaren

Säg hur många inlägg som kom med per kategori (skriptet skriver ut det), om några dubbletter togs bort, vad QA-kontrollen hittade och ändrade, och att PDF-versionen exporteras med taggar för tillgänglighet (Arkiv > Spara som > PDF > Alternativ > Visa taggar för dokumentstruktur).
