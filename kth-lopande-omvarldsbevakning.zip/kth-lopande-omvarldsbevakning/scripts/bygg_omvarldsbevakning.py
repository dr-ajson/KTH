#!/usr/bin/env python3
"""Bygg Ledningens omvärldsbevakning (KTH) i mallen KTH_lopandeomvarld.dotx.

    # från redaktionens betygsatta Excelfil (flik per kategori, kolumnen "Med?")
    python bygg_omvarldsbevakning.py --excel Omvarldsbevakning_2026-09-07_2026-09-26.xlsx \
        --datum 2026-10-06 -o "Ledningens omvärldsbevakning oktober 2026.docx"

    # från markdown:  # Kategori / ## Titel / sammanfattning / https://...
    python bygg_omvarldsbevakning.py --md utkast.md --datum 2026-10-06 -o ut.docx

Valfritt:
    --remisser remisser.xlsx     tabell under "Pågående utredningar/remisser"
    --utgivning "6 oktober, 10 november och 15 december HT2026"
                                 ersätter sista meningen i inledningen ("... utkommer ...")
    --min-summa 6                tas med om Summa >= värdet när "Med?" saknas (standard 6)
    --alla                       ta med alla rader oavsett betyg

Kräver python-docx och openpyxl.
"""
import argparse
import re
import sys
import tempfile
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path

from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Twips

KATEGORIER = [
    "Universitet och högskolor", "AI", "STEM", "Samverkan och innovation",
    "Hållbar utveckling", "Europa och EU", "Globalt", "Analyser och policydokument", "Debatt",
]
REMISS_RUBRIK = "Pågående utredningar/remisser"
REMISS_KOLUMNER = ["Dnr", "Inkom datum", "Rubrik", "Från", "Svar senast", "Lottas till/Avstå"]


def _hitta(rel):
    here = Path(__file__).resolve().parent
    for p in (here.parent / rel, here / Path(rel).name, Path("/mnt/data") / Path(rel).name):
        if p.exists():
            return p
    return here.parent / rel


MALL = _hitta("assets/KTH_lopandeomvarld.dotx")


# ------------------------------------------------------------------ indata

def ren(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def las_excel(path, min_summa, alla):
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)
    poster = {}
    for ws in wb.worksheets:
        kat = ws.title.strip()
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        head = [ren(h).casefold() for h in rows[0]]
        col = {n: head.index(n) for n in head if n}

        def get(r, *namn):
            for n in namn:
                if n in col and col[n] < len(r):
                    return r[col[n]]
            return None

        if "titel" not in col or not any(k in col for k in ("länk", "lank", "url")):
            continue
        for r in rows[1:]:
            titel, lank = ren(get(r, "titel")), ren(get(r, "länk", "lank", "url"))
            if not titel or not lank:
                continue
            med = ren(get(r, "med?", "med")).casefold()
            summa = get(r, "summa")
            if not alla:
                if med:
                    if med != "med":
                        continue
                elif not (isinstance(summa, (int, float)) and summa >= min_summa):
                    continue
            poster.setdefault(kat, []).append({
                "titel": titel, "sammanfattning": ren(get(r, "sammanfattning")),
                "lank": lank, "datum": get(r, "publikationsdatum", "publiceringsdatum"),
            })
    return poster


def las_md(path):
    poster, kat, post = {}, None, None
    for rad in Path(path).read_text(encoding="utf-8").splitlines():
        r = rad.strip().rstrip("\\").strip()
        if r.startswith("# "):
            kat = re.sub(r"^\d+\.\s*", "", r[2:]).strip()
            post = None
        elif r.startswith("## "):
            post = {"titel": r[3:].strip(), "sammanfattning": "", "lank": "", "datum": None}
            poster.setdefault(kat or "Övrigt", []).append(post)
        elif post is not None and r:
            m = re.match(r"^(?:länk:\s*)?(https?://\S+)$", r, re.I)
            d = re.match(r"^publiceringsdatum:\s*(.+)$", r, re.I)
            if m:
                post["lank"] = m.group(1)
            elif d:
                post["datum"] = d.group(1)
            elif not r.startswith(("**Datum", "**Period")):
                post["sammanfattning"] = (post["sammanfattning"] + " " + r).strip()
    return poster


def las_remisser(path):
    from openpyxl import load_workbook
    ws = load_workbook(path, data_only=True).worksheets[0]
    rows = [r for r in ws.iter_rows(values_only=True) if any(c not in (None, "") for c in r)]
    head = [ren(h).casefold() for h in rows[0]]
    alias = {"dnr": ["dnr", "nr", "diarienummer"], "inkom datum": ["inkom datum", "inkom"],
             "rubrik": ["rubrik"], "från": ["från", "avsändare"], "svar senast": ["svar senast"],
             "lottas till/avstå": ["lottas till/avstå", "lottas till", "kommentar"]}
    idx = []
    for k in REMISS_KOLUMNER:
        idx.append(next((head.index(a) for a in alias[k.casefold()] if a in head), None))
    ut = []
    for r in rows[1:]:
        ut.append([cell(r[i]) if i is not None and i < len(r) else "" for i in idx])
    return ut


def cell(v):
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return ren(v)


def ordna(poster):
    """Kategorier i fast ordning, okända sist; dubbletter (samma länk) tas bort."""
    sedda, ut = set(), []
    for kat in KATEGORIER + [k for k in poster if k not in KATEGORIER]:
        lista = []
        for p in poster.get(kat, []):
            nyckel = re.sub(r"[?#].*$", "", p["lank"]).rstrip("/").casefold()
            if nyckel in sedda:
                continue
            sedda.add(nyckel)
            lista.append(p)
        if lista:
            ut.append((kat, lista))
    return ut


# ------------------------------------------------------------------ dokument

def oppna_mall():
    tmp = Path(tempfile.mkdtemp()) / "mall.docx"
    with zipfile.ZipFile(MALL) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
        for item in zi.infolist():
            data = zi.read(item.filename)
            if item.filename == "[Content_Types].xml":
                data = data.replace(b"wordprocessingml.template.main+xml", b"wordprocessingml.document.main+xml")
            zo.writestr(item, data)
    return Document(str(tmp))


def satt_text(p_el, text):
    for sdt in list(p_el.iter(qn("w:sdt"))):
        content = sdt.find(qn("w:sdtContent"))
        i = sdt.getparent().index(sdt)
        for child in list(content):
            sdt.getparent().insert(i, child)
            i += 1
        sdt.getparent().remove(sdt)
    runs = [r for r in p_el.iter(qn("w:r")) if r.find(qn("w:t")) is not None]
    first = runs[0]
    for r in runs[1:]:
        r.getparent().remove(r)
    for t in first.findall(qn("w:t")):
        first.remove(t)
    rpr = first.find(qn("w:rPr"))
    if rpr is not None:
        first.remove(rpr)  # mallens titel har teckenavstånd per ord; nollställ
    t = OxmlElement("w:t")
    t.text = text
    t.set(qn("xml:space"), "preserve")
    first.append(t)


def lank(doc, p, url):
    r_id = doc.part.relate_to(url, RT.HYPERLINK, is_external=True)
    h = OxmlElement("w:hyperlink")
    h.set(qn("r:id"), r_id)
    h.set(qn("w:history"), "1")
    r = OxmlElement("w:r")
    rpr = OxmlElement("w:rPr")
    rs = OxmlElement("w:rStyle")
    rs.set(qn("w:val"), "Hyperlnk")
    rpr.append(rs)
    r.append(rpr)
    t = OxmlElement("w:t")
    t.text = url
    r.append(t)
    h.append(r)
    p._p.append(h)


def remisstabell(doc, rader):
    t = doc.add_table(rows=len(rader) + 1, cols=len(REMISS_KOLUMNER))
    t.style = doc.styles["Table Grid"]
    t.autofit = False
    bredd = [1229, 852, 2721, 2337, 757, 2230]  # samma kolumnbredder som i tidigare utgåvor (twips)
    grid = t._tbl.tblGrid
    for gc, w in zip(grid.findall(qn("w:gridCol")), bredd):
        gc.set(qn("w:w"), str(w))
    for i, rad in enumerate([REMISS_KOLUMNER] + rader):
        for j, v in enumerate(rad):
            c = t.cell(i, j)
            c.width = Twips(bredd[j])
            run = c.paragraphs[0].add_run(v)
            run.font.size = Pt(8)
            run.font.name = "Arial"
            run.font.bold = i == 0
    t.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    return t


def bygg(poster, datum, ut, remisser=None, utgivning=None):
    doc = oppna_mall()
    body = doc.element.body
    barn = [el for el in body if el.tag != qn("w:sectPr")]
    titel_p, intro_p = barn[0], barn[1]
    satt_text(titel_p, f"Ledningens omvärldsbevakning {datum}")
    if utgivning:
        intro = "".join(t.text or "" for t in intro_p.iter(qn("w:t")))
        intro = re.sub(r"[^.]*(skickas ut|utkommer)[^.]*\.\s*$", "", intro).strip()
        satt_text(intro_p, f"{intro} Ledningens omvärldsbevakning utkommer {utgivning.rstrip('.')}.")
    for el in barn[2:]:
        body.remove(el)

    antal = 0
    for kat, lista in ordna(poster):
        doc.add_paragraph(kat, style="Heading 1")
        for p in lista:
            doc.add_paragraph(p["titel"], style="Heading 2")
            b = doc.add_paragraph(style="Body Text")
            if p["sammanfattning"]:
                b.add_run(p["sammanfattning"])
                b.add_run().add_break()
            lank(doc, b, p["lank"])
            antal += 1
    if remisser:
        doc.add_paragraph(REMISS_RUBRIK, style="Heading 1")
        remisstabell(doc, remisser)
    cp = doc.core_properties
    cp.title = f"Ledningens omvärldsbevakning {datum}"
    cp.subject = "Urval av aktuella händelser, rapporter och debatt i KTH:s omvärld som underlag för KTH:s ledning."
    cp.language = "sv-SE"
    doc.save(ut)
    return antal


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    kalla = ap.add_mutually_exclusive_group(required=True)
    kalla.add_argument("--excel", help="redaktionens betygsatta Excelfil")
    kalla.add_argument("--md", help="markdown i formatet # Kategori / ## Titel / text / länk")
    ap.add_argument("--datum", default=date.today().isoformat(), help="utgivningsdatum ÅÅÅÅ-MM-DD")
    ap.add_argument("--remisser", help="Excelfil med remisser (Dnr, Inkom datum, Rubrik, Från, Svar senast, Lottas till/Avstå)")
    ap.add_argument("--utgivning", help="utgivningsdatum för terminen, ersätter sista meningen i inledningen")
    ap.add_argument("--min-summa", type=float, default=6)
    ap.add_argument("--alla", action="store_true")
    ap.add_argument("-o", "--ut", required=True)
    a = ap.parse_args()
    poster = las_excel(a.excel, a.min_summa, a.alla) if a.excel else las_md(a.md)
    if not poster:
        sys.exit("Inga poster hittades (kontrollera kolumnen 'Med?' eller använd --alla).")
    remisser = las_remisser(a.remisser) if a.remisser else None
    n = bygg(poster, a.datum, a.ut, remisser, a.utgivning)
    per_kat = ", ".join(f"{k}: {len(v)}" for k, v in ordna(poster))
    print(f"Skrev {a.ut} – {n} inlägg ({per_kat})" + (f", {len(remisser)} remisser" if remisser else ""))
    if not a.utgivning:
        print("OBS: inledningens sista mening (utgivningsdatum) är mallens gamla text. "
              "Ange --utgivning för att uppdatera den.", file=sys.stderr)


if __name__ == "__main__":
    main()
